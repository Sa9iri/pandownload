﻿
local curl = require "lcurl.safe"
local json = require "cjson.safe"
script_info = {
    ["title"] = "88888888",
    ["description"] = "我的简介",
    ["version"] = "7.0.6.11",
	["color"] = "#CCFFFF",
}
YWNjZWxlcmF0ZV91cmw = "https://d.pcs.baidu.com/rest/2.0/pcs/file?method=locatedownload"
function onInitTask(task, user, file)
if task:getType() ~= TASK_TYPE_SHARE_BAIDU then
return false
end
local ZVhoa1lYUmhNUQ = "BDUSS=NPODhadjRWZzZKVG9BYUdNSVQtQ1ZibXR2RW9mWEhpRlg3d0REQjZOSlBNLTlmSVFBQUFBJCQAAAAAAAAAAAEAAACv16U0xOPDw8Loz7sAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE-mx19Ppsdfb2"
local ZW5hYmxlLWh0dHAtcGlwZWxpbmluZw = "enable-http-pipelining"
local dHJ1ZQ = "true"
local dGltZW91dA = 15
local YWxsb3ctcGllY2UtbGVuZ3RoLWNoYW5nZQ = "allow-piece-length-change"
local NE0 = "5M"
local cGllY2UtbGVuZ3Ro = "piece-length"
local c3NsX3ZlcmlmeWhvc3Q = 0
local UmFuZ2U6Ynl0ZXM9NDA5Ni04MTkx = "Range:bytes=4096-8191"
local eXhkYXRhMQ = "&version=6.9.7.4&devuid=BDIMXV2%2DO%5FBCE8AA3DE02E43D1855CFF543870715C%2DC%5F0%2DD%5FHBSE28011300955%5F00000001%2E%2DM%5F1831BFB4D79F%2DV%5FF163A081&rand=4069ca4ba02c3c256a270e0a6f6cf3bcf83934ad&time=1607946709"
local ZGF0YQ = ""
local c3NsX3ZlcmlmeXBlZXI = 0
local dXNlci1hZ2VudA = "user-agent"
local aGVhZGVy = { "User-Agent: netdisk;6.9.5.1;PC;PC-Windows;6.3.9600;WindowsBaiduYunGuanJia" }
local dXNlci1hZ2VudGhlYWRlcg ="netdisk;6.9.5.1;PC;PC-Windows;6.3.9600;WindowsBaiduYunGuanJia"
local dnJlc3ZlcnNoc2VyYw = "header"
local cG9zdA = 1
local eXhkYXRhTktWSEJFS0RTSg = "app_id=250528&check_blue=1&es=1&esl=1&ver=4.0&dtype=1&err_ver=1.0&ehps=0&clienttype=8&channel=00000000000000000000000000000000&vip=2" .. string.gsub(string.gsub(file.dlink, "https://d.pcs.baidu.com/file/", "&path="), "?fid", "&fid") .. eXhkYXRhMQ
table.insert(aGVhZGVy, "Cookie: "..ZVhoa1lYUmhNUQ)
local Y2VzY3ZhY3dh = curl.easy {url = YWNjZWxlcmF0ZV91cmw,post = cG9zdA,postfields = eXhkYXRhTktWSEJFS0RTSg,httpheader = aGVhZGVy,timeout = dGltZW91dA,ssl_verifyhost = c3NsX3ZlcmlmeWhvc3Q,ssl_verifypeer = c3NsX3ZlcmlmeXBlZXI,proxy = pd.getProxy(),writefunction = function(buffer)ZGF0YQ = ZGF0YQ .. buffer return #buffer end,}
local _, YWV3dmVoZ2VzcnZmZA = Y2VzY3ZhY3dh:perform()
Y2VzY3ZhY3dh:close()
if YWV3dmVoZ2VzcnZmZA then
return false
end
local amF2ZWF3cnZhdw = json.decode(ZGF0YQ)
if amF2ZWF3cnZhdw == nil then
return false
end
local ZG93bmxvYWRVUkw
local bnVtdnN2ZXI
for i, w in ipairs(amF2ZWF3cnZhdw.urls) do
bnVtdnN2ZXI = i
end
ZG93bmxvYWRVUkw = amF2ZWF3cnZhdw.urls[bnVtdnN2ZXI].url
task:setUris(ZG93bmxvYWRVUkw)
task:setOptions(dXNlci1hZ2VudA, dXNlci1hZ2VudGhlYWRlcg)
if file.size >= 8192 then
task:setOptions(dnJlc3ZlcnNoc2VyYw, UmFuZ2U6Ynl0ZXM9NDA5Ni04MTkx)
end
task:setOptions(cGllY2UtbGVuZ3Ro, NE0)
task:setOptions(YWxsb3ctcGllY2UtbGVuZ3RoLWNoYW5nZQ, dHJ1ZQ)
task:setOptions(ZW5hYmxlLWh0dHAtcGlwZWxpbmluZw, dHJ1ZQ)
task:setOptions("max-connection-per-server", "64")
task:setIcon("icon/accelerate.png", "极速下载中")
return true
end
             